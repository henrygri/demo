<?php
/*
* 2007-2017 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author PrestaShop SA <contact@prestashop.com>
*  @copyright  2007-2015 PrestaShop SA
*  @license    http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/



if (!defined('_PS_VERSION_')) {
    exit;
}

use PrestaShop\PrestaShop\Core\Module\WidgetInterface;

class customForms extends Module implements WidgetInterface
{
	private $customfield;

	public function __construct()
    {
        $this->name = 'customForms';
        $this->tab = 'front_office_features';
        $this->author = 'Pradeep';
        $this->version = '1.0.0';
        $this->bootstrap = true;
        $this->need_instance = 0;
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->trans('Custom form blocks', array(), 'Modules.customForms.Admin');
        $this->description = $this->trans('Integrates custom forms blocks anywhere.', array(), 'Modules.customForms.Admin');

        $this->confirmUninstall = $this->l('Are you sure you want to uninstall?');

        if (!Configuration::get('CUSTOMDATA'))
    		$this->warning = $this->l('No name provided.');
        	
        $this->ps_versions_compliancy = array('min' => '1.7.1.0', 'max' => _PS_VERSION_);

        $this->templateFile = 'module:customforms/customforms.tpl';
    }

    /**
     * @see Module::install()
     */
    public function install()
	{
	  if (Shop::isFeatureActive())
	    Shop::setContext(Shop::CONTEXT_ALL);
	 
	  return parent::install() &&
	    $this->registerHook('leftColumn') &&
	    $this->registerHook('header') &&
	    Configuration::updateValue('CUSTOMDATA', 'my friend') &&
	    $this->createTab('AdminCustomTab', 'AdminCatalog', array(
     	'en' => 'My custom tab'
  		));
	}

    public function uninstall()
	{
	  
	  // if (!parent::uninstall() && !Configuration::deleteByName('CUSTOMDATA'))	
	  //   return false;

	  return parent::uninstall() && Configuration::deleteByName('CUSTOMDATA');
	}

	public function getContent()
	{
	    $output = null;
	 
	    if (Tools::isSubmit('submit'.$this->name))
	    {
	        $customformname = strval(Tools::getValue('CUSTOMDATA'));
	        if (!$customformname
	          || empty($customformname)
	          || !Validate::isGenericName($customformname))
	            $output .= $this->displayError($this->l('Invalid Configuration value'));
	        else
	        {
	            Configuration::updateValue('CUSTOMDATA', $customformname);
	            $output .= $this->displayConfirmation($this->l('Settings updated'));
	        }
	    }
	    return $output.$this->displayForm();
	}


	public function displayForm()
	{
	    // Get default language
	    $default_lang = (int)Configuration::get('PS_LANG_DEFAULT');
	 
	    // Init Fields form array
	    $fields_form[0]['form'] = array(
	        'legend' => array(
	            'title' => $this->l('Settings'),
	        ),
	        'input' => array(
	            array(
	                'type' => 'textarea',
	                'label' => $this->l('Custom value'),
	                'name' => 'CUSTOMDATA',
	                'size' => 20,
	                'required' => true
	            )
	        ),
	        'submit' => array(
	            'title' => $this->l('Save'),
	            'class' => 'btn btn-default pull-right'
	        )
	    );
	 
	    $helper = new HelperForm();
	 
	    // Module, token and currentIndex
	    $helper->module = $this;
	    $helper->name_controller = $this->name;
	    $helper->token = Tools::getAdminTokenLite('AdminModules');
	    $helper->currentIndex = AdminController::$currentIndex.'&configure='.$this->name;
	 
	    // Language
	    $helper->default_form_language = $default_lang;
	    $helper->allow_employee_form_lang = $default_lang;
	 
	    // Title and toolbar
	    $helper->title = $this->displayName;
	    $helper->show_toolbar = true;        // false -> remove toolbar
	    $helper->toolbar_scroll = true;      // yes - > Toolbar is always visible on the top of the screen.
	    $helper->submit_action = 'submit'.$this->name;
	    $helper->toolbar_btn = array(
	        'save' =>
	        array(
	            'desc' => $this->l('Save'),
	            'href' => AdminController::$currentIndex.'&configure='.$this->name.'&save'.$this->name.
	            '&token='.Tools::getAdminTokenLite('AdminModules'),
	        ),
	        'back' => array(
	            'href' => AdminController::$currentIndex.'&token='.Tools::getAdminTokenLite('AdminModules'),
	            'desc' => $this->l('Back to list')
	        )
	    );
	 
	    // Load current value
	    $helper->fields_value['CUSTOMDATA'] = Configuration::get('CUSTOMDATA');
	 
	    return $helper->generateForm($fields_form);
	}



	public function hookDisplayLeftColumn($params)
	{
	  /*$this->context->smarty->assign(
	      array(
	          'customformname' => Configuration::get('CUSTOMDATA')
	      )
	  );
	  return $this->display(__FILE__, 'customforms.tpl');*/
	}
	 
	public function hookDisplayRightColumn($params)
	{
	  //return $this->hookDisplayLeftColumn($params);
	}
	 
	public function hookDisplayHeader()
	{

	/* $this->context->smarty->assign(
	      array(
	          'customformname' => Configuration::get('CUSTOMDATA')
	      )
	  );

	  $this->context->controller->addCSS($this->_path.'css/mymodule.css', 'all');
	  return $this->display(__FILE__, 'customforms.tpl');*/
	  
	}


	public function renderWidget($hookName, array $configuration){
		$this->smarty->assign($this->getWidgetVariables($hookName, $configuration));
		$this->context->controller->addCSS($this->_path.'css/mymodule.css', 'all');
        return $this->display(__FILE__, 'customforms.tpl');
	}

	public function getWidgetVariables($hookName, array $configuration){
		$this->context->smarty->assign(
	      array(
	          'customformname' => Configuration::get('CUSTOMDATA')
	      )
	  	);
	}




}